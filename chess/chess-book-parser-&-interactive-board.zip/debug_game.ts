import { COMPACT_68_GAMES } from './src/all68GamesData';
import { Chess } from 'chess.js';

const game = COMPACT_68_GAMES.find(g => g.num === 3);
if (game) {
  const chess = new Chess();
  const initialMoves = game.initial.trim().split(/\s+/).filter(Boolean);
  console.log("Initial moves:", initialMoves);
  for (const m of initialMoves) {
    chess.move(m);
  }
  console.log("Board FEN after initial moves:", chess.fen());
  console.log("Whose turn is it?", chess.turn() === 'w' ? "White" : "Black");
  console.log("Legal moves in this position:", chess.moves());
  
  try {
    const res = chess.move("h4");
    console.log("Success playing h4! FEN:", chess.fen());
  } catch (err: any) {
    console.error("Error playing h4:", err.message);
  }
}
